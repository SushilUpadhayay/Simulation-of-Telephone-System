package telephone;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.Duration;
import java.util.*;
import javax.swing.JOptionPane;
import javax.swing.Timer;
import javax.swing.table.DefaultTableModel;
public class DelayCallSystem extends javax.swing.JFrame {
    // Constants
    private static final int MAX_LINKS = 3;
    private static final int TOTAL_LINES = 8;
    private static final int MIN_CALL_DURATION = 30; // seconds
    private static final int MAX_CALL_DURATION = 180; // seconds
    private static final int MIN_CALL_INTERVAL = 10; // seconds
    private static final int MAX_CALL_INTERVAL = 60; // seconds
    
    // Table column indices
    private static final int LINE_NUMBER_COL = 0;
    private static final int LINE_STATUS_COL = 1;
    
    // Simulation state
    private Duration simulationTime = Duration.ZERO;
    private Timer timer;
    private Random rand = new Random();
    
    // Call collections
    private PriorityQueue<Call> futureCalls = new PriorityQueue<>(Comparator.comparingInt(Call::getArrivalTimeInSeconds));
    private Queue<Call> waitingCalls = new LinkedList<>();
    private Set<Call> activeCalls = new HashSet<>();

    public DelayCallSystem() {
        initComponents();
        initializeTables();
        generateInitialCalls(5);
        startSimulation();
    }
    
    private void initializeTables() {
        // Initialize line status table
        DefaultTableModel lineModel = (DefaultTableModel) jTable2.getModel();
        for (int i = 0; i < TOTAL_LINES; i++) {
            lineModel.setValueAt(i + 1, i, LINE_NUMBER_COL);
            lineModel.setValueAt(false, i, LINE_STATUS_COL);
        }
        
        // Initialize other tables
        clearTable(jTable4); // Calls in progress
        clearTable(jTable8); // Delayed calls
        clearTable(jTable1); // Next call
        
        // Initialize call counters
        DefaultTableModel counterModel = (DefaultTableModel) jTable5.getModel();
        counterModel.setValueAt(0, 0, 0); // Processed
        counterModel.setValueAt(0, 0, 1); // Completed
        counterModel.setValueAt(0, 0, 2); // Blocked
        counterModel.setValueAt(0, 0, 3); // Busy
        
        // Set max links
        jTable7.setValueAt(MAX_LINKS, 0, 0);
        jTable7.setValueAt(0, 0, 1); // Initially 0 links in use
    }
    
    private void generateInitialCalls(int count) {
        for (int i = 0; i < count; i++) {
            generateCall();
        }
    }
    
    private void generateCall() {
        int from = getRandomLine();
        int to = getRandomLine();
        while (to == from) {
            to = getRandomLine(); // avoid self-call
        }

        int duration = getRandom(MIN_CALL_DURATION, MAX_CALL_DURATION);
        int arrivalTime = calculateNextArrivalTime();
        
        Call call = new Call(from, to, duration, arrivalTime);
        futureCalls.add(call);
    }
    
    private int getRandomLine() {
        return rand.nextInt(TOTAL_LINES) + 1;
    }
    
    private int calculateNextArrivalTime() {
        if (futureCalls.isEmpty()) {
            return (int) simulationTime.getSeconds() + getRandom(MIN_CALL_INTERVAL, MAX_CALL_INTERVAL);
        }
        Call lastCall = futureCalls.peek();
        return lastCall.getArrivalTimeInSeconds() + getRandom(MIN_CALL_INTERVAL, MAX_CALL_INTERVAL);
    }
    
    private int getRandom(int min, int max) {
        return rand.nextInt((max - min) + 1) + min;
    }
    
    private void startSimulation() {
        timer = new Timer(1000, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                simulationTime = simulationTime.plusSeconds(1);
                updateClock();
                processCallArrivals();
                processCallCompletions();
                processWaitingCalls();
                updateLinkStatus();
                showNextCall();
            }
        });
        timer.start();
    }
    
    private void updateClock() {
        String time = String.format("%02d:%02d:%02d",
            simulationTime.toHours(),
            simulationTime.toMinutesPart(),
            simulationTime.toSecondsPart());
        jTable6.setValueAt(time, 0, 0);
    }
    
private void processCallArrivals() {
    // Process existing calls
    while (!futureCalls.isEmpty() && 
           futureCalls.peek().getArrivalTimeInSeconds() <= simulationTime.getSeconds()) {
        Call call = futureCalls.poll();
        
        if (canConnectCall(call)) {
            connectCall(call);
            updateCallCounters(1, 0, 0, 0);
        } else {
            waitingCalls.add(call);
            addDelayedCallToTable(call);
            updateCallCounters(1, 0, 0, 1);
        }
    }
    
    // Generate new calls when queue is empty/low
    if (futureCalls.isEmpty() || futureCalls.size() < 3) {
        generateCall(); // Generates 1 new call
    }
}
    
    private boolean canConnectCall(Call call) {
        return activeCalls.size() < MAX_LINKS && 
               isLineFree(call.from) && 
               isLineFree(call.to);
    }
    
    private void connectCall(Call call) {
        activeCalls.add(call);
        setLineStatus(call.from, true);
        setLineStatus(call.to, true);
        addActiveCallToTable(call);
    }
    
    private void processCallCompletions() {
        Iterator<Call> iterator = activeCalls.iterator();
        while (iterator.hasNext()) {
            Call call = iterator.next();
            if (call.getEndTimeInSeconds() <= simulationTime.getSeconds()) {
                disconnectCall(call, iterator);
                updateCallCounters(0, 1, 0, 0); // completed++
            }
        }
    }
    
    private void disconnectCall(Call call, Iterator<Call> iterator) {
        setLineStatus(call.from, false);
        setLineStatus(call.to, false);
        removeActiveCallFromTable(call);
        iterator.remove();
    }
    
    private void processWaitingCalls() {
        Iterator<Call> iterator = waitingCalls.iterator();
        while (iterator.hasNext() && activeCalls.size() < MAX_LINKS) {
            Call call = iterator.next();
            if (canConnectCall(call)) {
                iterator.remove();
                connectCall(call);
                removeDelayedCallFromTable(call);
                updateCallCounters(0, 0, 0, -1); // busy--
            }
        }
    }
    
    private void updateLinkStatus() {
        jTable7.setValueAt(activeCalls.size(), 0, 1);
    }
    
    private void showNextCall() {
        Call nextCall = futureCalls.peek();
        if (nextCall != null) {
            jTable1.setValueAt(nextCall.from, 0, 0);
            jTable1.setValueAt(nextCall.to, 0, 1);
            jTable1.setValueAt(formatMinutesSeconds(nextCall.duration), 0, 2); // Changed to MM:SS format
            jTable1.setValueAt(nextCall.getFormattedArrivalTime(), 0, 3);
        } else {
            clearTableRow(jTable1, 0);
        }
    }
    
    private String formatMinutesSeconds(int totalSeconds) {
        int minutes = totalSeconds / 60;
        int seconds = totalSeconds % 60;
        return String.format("%02d:%02d", minutes, seconds);
    }
    
    private void updateCallCounters(int processed, int completed, int blocked, int busy) {
        DefaultTableModel model = (DefaultTableModel) jTable5.getModel();
        model.setValueAt(getCounterValue(0) + processed, 0, 0);
        model.setValueAt(getCounterValue(1) + completed, 0, 1);
        model.setValueAt(getCounterValue(2) + blocked, 0, 2);
        model.setValueAt(getCounterValue(3) + busy, 0, 3);
    }
    
    private int getCounterValue(int column) {
        Object value = jTable5.getValueAt(0, column);
        return value != null ? (int) value : 0;
    }
    
    private boolean isLineFree(int lineNumber) {
        validateLineNumber(lineNumber);
        return !(boolean) jTable2.getValueAt(lineNumber - 1, LINE_STATUS_COL);
    }
    
    private void setLineStatus(int lineNumber, boolean status) {
        validateLineNumber(lineNumber);
        jTable2.setValueAt(status, lineNumber - 1, LINE_STATUS_COL);
    }
    
    private void validateLineNumber(int lineNumber) {
        if (lineNumber < 1 || lineNumber > TOTAL_LINES) {
            throw new IllegalArgumentException("Invalid line number: " + lineNumber);
        }
    }
    
    private void addActiveCallToTable(Call call) {
        DefaultTableModel model = (DefaultTableModel) jTable4.getModel();
        int emptyRow = findEmptyRow(model);
        if (emptyRow != -1) {
            model.setValueAt(call.from, emptyRow, 0);
            model.setValueAt(call.to, emptyRow, 1);
            model.setValueAt(formatTime(call.getEndTimeInSeconds()), emptyRow, 2);
        }
    }
    
    private void removeActiveCallFromTable(Call call) {
        DefaultTableModel model = (DefaultTableModel) jTable4.getModel();
        findAndClearRow(model, call.from, call.to);
    }
    
    private void addDelayedCallToTable(Call call) {
        DefaultTableModel model = (DefaultTableModel) jTable8.getModel();
        int emptyRow = findEmptyRow(model);
        if (emptyRow != -1) {
            model.setValueAt(call.from, emptyRow, 0);
            model.setValueAt(call.to, emptyRow, 1);
            model.setValueAt(formatMinutesSeconds(call.duration), emptyRow, 2); // Changed to MM:SS format
        }
    }
    
    private void removeDelayedCallFromTable(Call call) {
        DefaultTableModel model = (DefaultTableModel) jTable8.getModel();
        findAndClearRow(model, call.from, call.to);
    }
    
    private int findEmptyRow(DefaultTableModel model) {
        for (int i = 0; i < model.getRowCount(); i++) {
            if (model.getValueAt(i, 0) == null) {
                return i;
            }
        }
        return -1;
    }
    
    private void findAndClearRow(DefaultTableModel model, int from, int to) {
        for (int i = 0; i < model.getRowCount(); i++) {
            if (model.getValueAt(i, 0) != null && 
                (int) model.getValueAt(i, 0) == from && 
                (int) model.getValueAt(i, 1) == to) {
                clearTableRow(model, i);
                break;
            }
        }
    }
    
    private void clearTable(javax.swing.JTable table) {
        DefaultTableModel model = (DefaultTableModel) table.getModel();
        for (int i = 0; i < model.getRowCount(); i++) {
            clearTableRow(model, i);
        }
    }
    
    private void clearTableRow(DefaultTableModel model, int row) {
        for (int j = 0; j < model.getColumnCount(); j++) {
            model.setValueAt(null, row, j);
        }
    }
    
    private void clearTableRow(javax.swing.JTable table, int row) {
        DefaultTableModel model = (DefaultTableModel) table.getModel();
        clearTableRow(model, row);
    }
    
    private String formatTime(int seconds) {
        Duration duration = Duration.ofSeconds(seconds);
        return String.format("%02d:%02d:%02d",
            duration.toHours(),
            duration.toMinutesPart(),
            duration.toSecondsPart());
    }
    
    // Call inner class
    private class Call {
        final int from;
        final int to;
        final int duration;
        final int arrivalTime;
        
        Call(int from, int to, int duration, int arrivalTime) {
            this.from = from;
            this.to = to;
            this.duration = duration;
            this.arrivalTime = arrivalTime;
        }
        
        int getArrivalTimeInSeconds() {
            return arrivalTime;
        }
        
        int getEndTimeInSeconds() {
            return arrivalTime + duration;
        }
        
        String getFormattedArrivalTime() {
            return formatTime(arrivalTime);
        }
        
        @Override
        public String toString() {
            return String.format("From %d to %d at %s for %s", 
                from, to, getFormattedArrivalTime(), formatMinutesSeconds(duration));
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        jScrollPane4 = new javax.swing.JScrollPane();
        jTable4 = new javax.swing.JTable();
        jScrollPane6 = new javax.swing.JScrollPane();
        jTable6 = new javax.swing.JTable();
        jScrollPane7 = new javax.swing.JScrollPane();
        jTable7 = new javax.swing.JTable();
        jLabel3 = new javax.swing.JLabel();
        jScrollPane8 = new javax.swing.JScrollPane();
        jTable8 = new javax.swing.JTable();
        jLabel5 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jScrollPane5 = new javax.swing.JScrollPane();
        jTable5 = new javax.swing.JTable();
        jLabel4 = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jMenu2 = new javax.swing.JMenu();
        jMenu3 = new javax.swing.JMenu();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel2.setBackground(new java.awt.Color(255, 255, 153));
        jPanel2.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 3, true));

        jTable1.setAutoCreateRowSorter(true);
        jTable1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null}
            },
            new String [] {
                "FROM", "TO", "END", "ARRIVAL TIME"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.Integer.class, java.lang.Integer.class, java.lang.Integer.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable1.setShowGrid(true);
        jScrollPane1.setViewportView(jTable1);

        jLabel2.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel2.setText("NEXT CALL");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(59, 59, 59)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 390, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(265, 265, 265)
                        .addComponent(jLabel2)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 47, Short.MAX_VALUE)
                .addGap(22, 22, 22))
        );

        jPanel3.setBackground(new java.awt.Color(255, 51, 153));
        jPanel3.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 3, true));

        jTable2.setAutoCreateRowSorter(true);
        jTable2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                { new Integer(1), null},
                { new Integer(2), null},
                { new Integer(3), null},
                { new Integer(4), null},
                { new Integer(5), null},
                { new Integer(6), null},
                { new Integer(7), null},
                { new Integer(8), null}
            },
            new String [] {
                "TELEPHONES", "LINES"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.Boolean.class
            };
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable2.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_ALL_COLUMNS);
        jTable2.setFocusable(false);
        jTable2.setShowGrid(true);
        jScrollPane2.setViewportView(jTable2);

        jTable4.setAutoCreateRowSorter(true);
        jTable4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jTable4.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "FROM", "TO", "END"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.Integer.class, java.lang.Integer.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable4.setShowGrid(true);
        jScrollPane4.setViewportView(jTable4);

        jTable6.setAutoCreateRowSorter(true);
        jTable6.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jTable6.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null}
            },
            new String [] {
                "CLOCK"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class
            };
            boolean[] canEdit = new boolean [] {
                false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable6.setShowGrid(true);
        jScrollPane6.setViewportView(jTable6);

        jTable7.setAutoCreateRowSorter(true);
        jTable7.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jTable7.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null}
            },
            new String [] {
                "MAX LINKS", "USED LINKS"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.Integer.class
            };
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable7.setShowGrid(true);
        jScrollPane7.setViewportView(jTable7);

        jLabel3.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel3.setText("CALLS IN PROGRESS");

        jTable8.setAutoCreateRowSorter(true);
        jTable8.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jTable8.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "FROM", "TO", "END"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.Integer.class, java.lang.Integer.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable8.setShowGrid(true);
        jScrollPane8.setViewportView(jTable8);

        jLabel5.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel5.setText("DELAYED CALLS");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 184, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(50, 50, 50)
                        .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                                .addComponent(jLabel5)
                                .addGap(164, 164, 164))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jScrollPane8, javax.swing.GroupLayout.PREFERRED_SIZE, 239, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(jPanel3Layout.createSequentialGroup()
                                        .addComponent(jLabel3)
                                        .addGap(22, 22, 22)))
                                .addGap(87, 87, 87))))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(16, 16, 16)
                        .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, 176, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 75, Short.MAX_VALUE)
                        .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 217, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(69, 69, 69))))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 187, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(jLabel5)
                        .addGap(9, 9, 9)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(jScrollPane8, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jLabel3)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(23, Short.MAX_VALUE))
        );

        jPanel4.setBackground(new java.awt.Color(255, 204, 204));
        jPanel4.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 3, true));

        jTable5.setAutoCreateRowSorter(true);
        jTable5.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jTable5.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null}
            },
            new String [] {
                "PROCESSED", "COMPLETED", "BLOCKED", "BUSY"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.Integer.class, java.lang.Integer.class, java.lang.Integer.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable5.setShowGrid(true);
        jScrollPane5.setViewportView(jTable5);

        jLabel4.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel4.setText("CALL COUNTERS");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(133, 133, 133)
                        .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 331, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(224, 224, 224)
                        .addComponent(jLabel4)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addContainerGap(18, Short.MAX_VALUE)
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(23, 23, 23))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jMenu1.setText("About Us");
        jMenu1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jMenu1MouseClicked(evt);
            }
        });
        jMenuBar1.add(jMenu1);

        jMenu2.setText("Help");
        jMenu2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jMenu2MouseClicked(evt);
            }
        });
        jMenuBar1.add(jMenu2);

        jMenu3.setText("Contact Us");
        jMenu3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jMenu3MouseClicked(evt);
            }
        });
        jMenuBar1.add(jMenu3);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jMenu1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenu1MouseClicked
        String aboutMessage = 
        "<html><div style='text-align: center;'>" +
        "<h2>Lost Call Management System</h2>" +
        "<p><b>Version:</b> 1.0.0</p>" +
        "<p><b>Developed by:</b> [Sushil Upadhayay]</p>" +
        "<p><b>Owner:</b> [Upadhayay Groups of Industries]</p>" +       
        "<p><b>© 2023</b> All Rights Reserved</p>" +
        "</div></html>";

    // Show the dialog with an icon
    JOptionPane.showMessageDialog(
        this,                       // Parent component (the main window)
        aboutMessage,               // Formatted message
        "About Us",                 // Dialog title
        JOptionPane.INFORMATION_MESSAGE); // Message type
    }//GEN-LAST:event_jMenu1MouseClicked

    private void jMenu2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenu2MouseClicked
        String helpMessage = 
        "<html><div style='text-align: left; width: 300px;'>" +
        "<h2 style='color: #0066cc;'>Lost Call System Help</h2>" +
        "<p><b>1. Starting the Simulation:</b><br>" +
        "Run <b>DelayCallSystem</b> to begin call processing.</p>" +
        "<p><b>2. Stopping the Simulation:</b><br>" +
        "Click <b>Cross X at top</b> to end the simulation.</p>" +
        "<p><b>3. Understanding Tables:</b><br>" +
        "- <b>Next Call:</b> Shows upcoming calls<br>" +
        "- <b>Active Calls:</b> Displays ongoing calls<br>" +
        "- <b>Lines:</b> Shows telephone line status</p>" +
        "<p><b>4. Troubleshooting:</b><br>" +
        "If the system freezes, restart the application.</p>" +
        "<hr>" +
        "<p style='text-align: center;'><i>For further assistance, contact support@delaycalltelephone.com</i></p>" +
        "</div></html>";

    // Show help dialog with question icon
    JOptionPane.showMessageDialog(
        this,
        helpMessage,
        "Help Guide",
        JOptionPane.QUESTION_MESSAGE
    );
    }//GEN-LAST:event_jMenu2MouseClicked

    private void jMenu3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenu3MouseClicked
        // TODO add your handling code here:
        // contact us
         // Create a visually appealing contact message
    String contactMessage = 
        "<html><div style='width: 350px; text-align: center;'>" +
        "<h2 style='color: #2E86C1;'>Contact Our Team</h2>" +
        "<p style='font-size: 14px;'><b>Lost Call Management System</b></p>" +
        "<hr style='border-top: 1px solid #D5D8DC;'>" +
        "<p><b>📞 Support Hotline:</b><br>1660 01 2356</p>" +
        "<p><b>✉ Email:</b><br>support@delaycalltelephone.com</p>" +
        "<p><b>🏢 Address:</b><br>Kathmandu, ABC<br>Nepal</p>" +
        "<hr style='border-top: 1px solid #D5D8DC;'>" +
        "<p style='color: #5D6D7E; font-size: 12px;'>" +
        "Available Monday-Friday, 9AM-5PM PST</p>" +
        "</div></html>";
    JOptionPane.showMessageDialog(
        this,
        contactMessage,
        "Contact Us",
        JOptionPane.PLAIN_MESSAGE);
    }//GEN-LAST:event_jMenu3MouseClicked

    public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(DelayCallSystem.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(DelayCallSystem.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(DelayCallSystem.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(DelayCallSystem.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new DelayCallSystem().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenu jMenu3;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JScrollPane jScrollPane8;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable2;
    private javax.swing.JTable jTable4;
    private javax.swing.JTable jTable5;
    private javax.swing.JTable jTable6;
    private javax.swing.JTable jTable7;
    private javax.swing.JTable jTable8;
    // End of variables declaration//GEN-END:variables
}
