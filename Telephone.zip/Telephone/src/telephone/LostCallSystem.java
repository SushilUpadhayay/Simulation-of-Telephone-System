package telephone;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;
import javax.swing.JOptionPane;
import javax.swing.Timer;
import javax.swing.table.DefaultTableModel;

public class LostCallSystem extends javax.swing.JFrame {
    private final int MAX_LINKS = 3;
    private final int TOTAL_LINES = 8;
    private int secondsElapsed = 0;
    private Timer timer;
    private Random rand = new Random();
    private ArrayList<ArrivalCallDelay> arrivalCalls = new ArrayList<>();
    private ArrayList<ArrivalCallDelay> activeCalls = new ArrayList<>();
    private int[] lineStatus = new int[TOTAL_LINES + 1]; // Index 1-8

    public LostCallSystem() {
        initComponents();
        initializeTables();
        generateInitialCalls();
        startClock();
    }
    private void generateInitialCalls() {
        for (int i = 0; i < 5; i++) {
            generateCall();
        }
        updateNextCallTable();
    }

    private void initializeTables() {
        // Initialize Lines table
        DefaultTableModel linesModel = (DefaultTableModel) jTable2.getModel();
        for (int i = 1; i <= TOTAL_LINES; i++) {
            linesModel.setValueAt(i, i-1, 0);
            linesModel.setValueAt(false, i-1, 1);
        }
        
        // Initialize Links table
        DefaultTableModel linksModel = (DefaultTableModel) jTable7.getModel();
        linksModel.setValueAt(MAX_LINKS, 0, 0);
        linksModel.setValueAt(0, 0, 1);
        
        // Initialize other tables
        DefaultTableModel nextCallModel = (DefaultTableModel) jTable1.getModel();
        nextCallModel.setValueAt("--", 0, 0);
        nextCallModel.setValueAt("--", 0, 1);
        nextCallModel.setValueAt("--", 0, 2);
        nextCallModel.setValueAt("--", 0, 3);
        
        DefaultTableModel activeCallsModel = (DefaultTableModel) jTable4.getModel();
        for (int i = 0; i < 3; i++) {
            activeCallsModel.setValueAt("--", i, 0);
            activeCallsModel.setValueAt("--", i, 1);
            activeCallsModel.setValueAt("--", i, 2);
        }
        
        DefaultTableModel countersModel = (DefaultTableModel) jTable5.getModel();
        countersModel.setValueAt(0, 0, 0);
        countersModel.setValueAt(0, 0, 1);
        countersModel.setValueAt(0, 0, 2);
        countersModel.setValueAt(0, 0, 3);
        
        DefaultTableModel clockModel = (DefaultTableModel) jTable6.getModel();
        clockModel.setValueAt("00:00:00", 0, 0);
    }

private void generateCall() {
    int from = getRandom(1, TOTAL_LINES);
    int to = getRandom(1, TOTAL_LINES);
    while (to == from) to = getRandom(1, TOTAL_LINES);

    int length = getRandom(30, 180);
    int arrivalTime = secondsElapsed + getRandom(10, 60);
    
    ArrivalCallDelay call = new ArrivalCallDelay(from, to, length, arrivalTime);
    arrivalCalls.add(call);
    arrivalCalls.sort((c1, c2) -> Integer.compare(c1.arrivalTime, c2.arrivalTime));
}
    private void updateNextCallTable() {
        DefaultTableModel nextCallModel = (DefaultTableModel) jTable1.getModel();

        // Clear current values
        nextCallModel.setValueAt("--", 0, 0);
        nextCallModel.setValueAt("--", 0, 1);
        nextCallModel.setValueAt("--", 0, 2);
        nextCallModel.setValueAt("--", 0, 3);

        // Find the next future call that hasn't been processed yet
        for (ArrivalCallDelay call : arrivalCalls) {
            if (call.arrivalTime > secondsElapsed) {
                nextCallModel.setValueAt(call.from, 0, 0);
                nextCallModel.setValueAt(call.to, 0, 1);
                nextCallModel.setValueAt(call.length + " sec", 0, 2);
                nextCallModel.setValueAt(formatTime(call.arrivalTime), 0, 3);
                break;
            }
        }
    }
    private void startClock() {
        timer = new Timer(1000, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                secondsElapsed++;

                // Update clock display
                DefaultTableModel clockModel = (DefaultTableModel) jTable6.getModel();
                clockModel.setValueAt(formatTime(secondsElapsed), 0, 0);

                // Process active calls (check for completed calls)
                processActiveCalls();

                // Process arriving calls
                processArrivingCalls();

                // Update next call display
                updateNextCallTable();

                // Improved call generation logic
                if (arrivalCalls.size() < 3 || secondsElapsed % 15 == 0) {
                    generateCall();
                    updateNextCallTable();
                }
            }
        });
        timer.start();
    }

private void processActiveCalls() {
    Iterator<ArrivalCallDelay> activeIter = activeCalls.iterator();
    while (activeIter.hasNext()) {
        ArrivalCallDelay call = activeIter.next();
        if (secondsElapsed >= call.getArrivalTimeInSeconds() + call.length) {
            // Call completed successfully
            lineStatus[call.from] = 0;
            lineStatus[call.to] = 0;
            updateLineStatus(call.from, false);
            updateLineStatus(call.to, false);
            activeIter.remove();
            updateActiveCallsTable();

            // Only increment COMPLETED when call actually finishes
            incrementCounter("COMPLETED");

            // Update links count
            ((DefaultTableModel)jTable7.getModel()).setValueAt(activeCalls.size(), 0, 1);
        }
    }
}
    private void processArrivingCalls() {
    while (!arrivalCalls.isEmpty()) {
        ArrivalCallDelay nextCall = arrivalCalls.get(0);

        if (nextCall.arrivalTime <= secondsElapsed) {
            // Remove call from queue
            arrivalCalls.remove(0);
            updateNextCallTable();

            // All calls are counted as PROCESSED when they arrive
            incrementCounter("PROCESSED");

            if (activeCalls.size() < MAX_LINKS && 
                lineStatus[nextCall.from] == 0 && 
                lineStatus[nextCall.to] == 0) {

                // Successful connection (add to active calls)
                activeCalls.add(nextCall);
                lineStatus[nextCall.from] = 1;
                lineStatus[nextCall.to] = 1;

                updateLineStatus(nextCall.from, true);
                updateLineStatus(nextCall.to, true);
                updateActiveCallsTable();

                // Update links count (do NOT increment COMPLETED here)
                ((DefaultTableModel)jTable7.getModel()).setValueAt(activeCalls.size(), 0, 1);

            } else if (activeCalls.size() >= MAX_LINKS) {
                // System full → BLOCKED call
                incrementCounter("BLOCKED");
            } else {
                // Lines busy → BUSY call
                incrementCounter("BUSY");
            }
        } else {
            break;
        }
    }
}
    private void updateActiveCallsTable() {
        DefaultTableModel activeCallsModel = (DefaultTableModel) jTable4.getModel();

        // Clear the table first
        for (int i = 0; i < activeCallsModel.getRowCount(); i++) {
            activeCallsModel.setValueAt("--", i, 0);
            activeCallsModel.setValueAt("--", i, 1);
            activeCallsModel.setValueAt("--", i, 2);
        }

        // Only populate with currently active calls
        for (int i = 0; i < activeCalls.size() && i < 3; i++) {
            ArrivalCallDelay call = activeCalls.get(i);
            activeCallsModel.setValueAt(call.from, i, 0);
            activeCallsModel.setValueAt(call.to, i, 1);
            activeCallsModel.setValueAt(formatTime(call.getArrivalTimeInSeconds() + call.length), i, 2);
        }
    }
    private void updateLineStatus(int line, boolean busy) {
        DefaultTableModel linesModel = (DefaultTableModel) jTable2.getModel();
        linesModel.setValueAt(busy, line-1, 1);
    }
    
    // Updated counter method with clear documentation
    private void incrementCounter(String counterType) {
        DefaultTableModel countersModel = (DefaultTableModel) jTable5.getModel();
        int col = -1;

        /**
         * Counter Definitions:
         * 0 - PROCESSED: All calls that enter the system (including completed, blocked, busy)
         * 1 - COMPLETED: Calls that successfully connected and finished
         * 2 - BLOCKED: Calls rejected due to full system capacity (all links occupied)
         * 3 - BUSY: Calls rejected due to specific line unavailability (some links free but needed lines busy)
         */
        switch(counterType) {
            case "PROCESSED": col = 0; break;
            case "COMPLETED": col = 1; break;
            case "BLOCKED": col = 2; break;
            case "BUSY": col = 3; break;
        }

        if (col >= 0) {
            Integer current = (Integer) countersModel.getValueAt(0, col);
            countersModel.setValueAt((current != null ? current : 0) + 1, 0, col);
        }
    }
    private int getRandom(int min, int max) {
        return rand.nextInt((max - min) + 1) + min;
    }
    
    private String formatTime(int totalSeconds) {
        int h = totalSeconds / 3600;
        int m = (totalSeconds % 3600) / 60;
        int s = totalSeconds % 60;
        return String.format("%02d:%02d:%02d", h, m, s);
    }
class ArrivalCallDelay {
        int from;
        int to;
        int length; // in seconds
        int arrivalTime; // in seconds
        
        public ArrivalCallDelay(int from, int to, int length, int arrivalTime) {
            this.from = from;
            this.to = to;
            this.length = length;
            this.arrivalTime = arrivalTime;
        }
        
        public int getArrivalTimeInSeconds() {
            return arrivalTime;
        }
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jMenuItem1 = new javax.swing.JMenuItem();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        jScrollPane4 = new javax.swing.JScrollPane();
        jTable4 = new javax.swing.JTable();
        jScrollPane6 = new javax.swing.JScrollPane();
        jTable6 = new javax.swing.JTable();
        jScrollPane7 = new javax.swing.JScrollPane();
        jTable7 = new javax.swing.JTable();
        jLabel3 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jScrollPane5 = new javax.swing.JScrollPane();
        jTable5 = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu2 = new javax.swing.JMenu();
        jMenu3 = new javax.swing.JMenu();
        jMenu4 = new javax.swing.JMenu();

        jMenuItem1.setText("jMenuItem1");

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jPanel1.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 2, true));

        jPanel2.setBackground(new java.awt.Color(255, 255, 153));
        jPanel2.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 3, true));

        jTable1.setAutoCreateRowSorter(true);
        jTable1.setBackground(new java.awt.Color(153, 255, 255));
        jTable1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null}
            },
            new String [] {
                "FROM", "TO", "END", "ARRIVAL TIME"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.Integer.class, java.lang.Integer.class, java.lang.Integer.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable1.setSelectionForeground(new java.awt.Color(102, 255, 102));
        jTable1.setShowGrid(true);
        jScrollPane1.setViewportView(jTable1);

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("NEXT CALL");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(59, 59, 59)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 390, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(208, 208, 208)
                        .addComponent(jLabel2)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(36, Short.MAX_VALUE))
        );

        jPanel3.setBackground(new java.awt.Color(204, 255, 255));
        jPanel3.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 3, true));

        jTable2.setAutoCreateRowSorter(true);
        jTable2.setBackground(new java.awt.Color(204, 255, 204));
        jTable2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                { new Integer(1), null},
                { new Integer(2), null},
                { new Integer(3), null},
                { new Integer(4), null},
                { new Integer(5), null},
                { new Integer(6), null},
                { new Integer(7), null},
                { new Integer(8), null}
            },
            new String [] {
                "TELEPHONES", "LINES"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.Boolean.class
            };
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable2.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_ALL_COLUMNS);
        jTable2.setFocusable(false);
        jTable2.setShowGrid(true);
        jScrollPane2.setViewportView(jTable2);

        jTable4.setAutoCreateRowSorter(true);
        jTable4.setBackground(new java.awt.Color(255, 153, 153));
        jTable4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jTable4.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "FROM", "TO", "END"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.Integer.class, java.lang.Integer.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable4.setSelectionForeground(new java.awt.Color(51, 51, 51));
        jTable4.setShowGrid(true);
        jScrollPane4.setViewportView(jTable4);

        jTable6.setAutoCreateRowSorter(true);
        jTable6.setBackground(new java.awt.Color(153, 255, 204));
        jTable6.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jTable6.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null}
            },
            new String [] {
                "CLOCK"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class
            };
            boolean[] canEdit = new boolean [] {
                false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable6.setShowGrid(true);
        jScrollPane6.setViewportView(jTable6);

        jTable7.setAutoCreateRowSorter(true);
        jTable7.setBackground(new java.awt.Color(255, 153, 255));
        jTable7.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jTable7.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null}
            },
            new String [] {
                "MAX LINKS", "USED LINKS"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.Integer.class
            };
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable7.setShowGrid(true);
        jScrollPane7.setViewportView(jTable7);

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel3.setText("CALLS IN PROGRESS");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 184, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, 176, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 21, Short.MAX_VALUE)
                                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 217, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addContainerGap())
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel3)
                        .addGap(46, 46, 46))))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 187, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(39, 39, 39)
                        .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 8, Short.MAX_VALUE)
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane4, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jScrollPane6, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(19, Short.MAX_VALUE))
        );

        jPanel4.setBackground(new java.awt.Color(204, 255, 204));
        jPanel4.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 3, true));

        jTable5.setAutoCreateRowSorter(true);
        jTable5.setBackground(new java.awt.Color(255, 255, 153));
        jTable5.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jTable5.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null}
            },
            new String [] {
                "PROCESSED", "COMPLETED", "BLOCKED", "BUSY"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.Integer.class, java.lang.Integer.class, java.lang.Integer.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable5.setShowGrid(true);
        jScrollPane5.setViewportView(jTable5);

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel1.setText("CALL COUNTERS");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(189, 189, 189)
                        .addComponent(jLabel1))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(68, 68, 68)
                        .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 433, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addContainerGap(12, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(17, 17, 17))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel4, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jMenuBar1.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 2, true));

        jMenu2.setText("Help");
        jMenu2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jMenu2MouseClicked(evt);
            }
        });
        jMenuBar1.add(jMenu2);

        jMenu3.setText("Contact us");
        jMenu3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jMenu3MouseClicked(evt);
            }
        });
        jMenuBar1.add(jMenu3);

        jMenu4.setText("About us");
        jMenu4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jMenu4MouseClicked(evt);
            }
        });
        jMenuBar1.add(jMenu4);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(14, Short.MAX_VALUE)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jMenu2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenu2MouseClicked
           String helpMessage = 
        "<html><div style='text-align: left; width: 300px;'>" +
        "<h2 style='color: #0066cc;'>Lost Call System Help</h2>" +
        "<p><b>1. Starting the Simulation:</b><br>" +
        "Run <b>LostCallSystem</b> to begin call processing.</p>" +
        "<p><b>2. Stopping the Simulation:</b><br>" +
        "Click <b>Cross X at top</b> to end the simulation.</p>" +
        "<p><b>3. Understanding Tables:</b><br>" +
        "- <b>Next Call:</b> Shows upcoming calls<br>" +
        "- <b>Active Calls:</b> Displays ongoing calls<br>" +
        "- <b>Lines:</b> Shows telephone line status</p>" +
        "<p><b>4. Troubleshooting:</b><br>" +
        "If the system freezes, restart the application.</p>" +
        "<hr>" +
        "<p style='text-align: center;'><i>For further assistance, contact support@lostcalltelephone.com</i></p>" +
        "</div></html>";

    // Show help dialog with question icon
    JOptionPane.showMessageDialog(
        this,
        helpMessage,
        "Help Guide",
        JOptionPane.QUESTION_MESSAGE
    );
    }//GEN-LAST:event_jMenu2MouseClicked

    private void jMenu4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenu4MouseClicked
        String aboutMessage = 
        "<html><div style='text-align: center;'>" +
        "<h2>Upadhayay Telephone Service</h2>" +
        "<p><b>Version:</b> 1.0.0</p>" +
        "<p><b>Developed by:</b> [Sushil Upadhayay]</p>" +
        "<p><b>Owner:</b> [Upadhayay Groups of Industries]</p>" +       
        "<p><b>© 2023</b> All Rights Reserved</p>" +
        "</div></html>";

    // Show the dialog with an icon
    JOptionPane.showMessageDialog(
        this,                       // Parent component (the main window)
        aboutMessage,               // Formatted message
        "About Us",                 // Dialog title
        JOptionPane.INFORMATION_MESSAGE); // Message type
    }//GEN-LAST:event_jMenu4MouseClicked

    private void jMenu3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenu3MouseClicked
        String contactMessage = 
        "<html><div style='width: 350px; text-align: center;'>" +
        "<h2 style='color: #2E86C1;'>Contact Our Team</h2>" +
        "<p style='font-size: 14px;'><b>Upadhayay Telephone Service</b></p>" +
        "<hr style='border-top: 1px solid #D5D8DC;'>" +
        "<p><b>📞 Support Hotline:</b><br>1660 01 2356</p>" +
        "<p><b>✉ Email:</b><br>support@lostcalltelephone.com</p>" +
        "<p><b>🏢 Address:</b><br>Kathmandu, ABC<br>Nepal</p>" +
        "<hr style='border-top: 1px solid #D5D8DC;'>" +
        "<p style='color: #5D6D7E; font-size: 12px;'>" +
        "Available Monday-Friday, 9AM-5PM PST</p>" +
        "</div></html>";
    JOptionPane.showMessageDialog(
        this,
        contactMessage,
        "Contact Us",
        JOptionPane.PLAIN_MESSAGE);
    }//GEN-LAST:event_jMenu3MouseClicked

    public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(LostCallSystem.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(LostCallSystem.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(LostCallSystem.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(LostCallSystem.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new LostCallSystem().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenu jMenu3;
    private javax.swing.JMenu jMenu4;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable2;
    private javax.swing.JTable jTable4;
    private javax.swing.JTable jTable5;
    private javax.swing.JTable jTable6;
    private javax.swing.JTable jTable7;
    // End of variables declaration//GEN-END:variables
}
