package telephone;

import java.awt.*;
import java.io.File;
import javax.swing.*;
import javax.imageio.ImageIO;

public class Welcome extends javax.swing.JFrame {
    private Image backgroundImage;
    
    public Welcome() {
        initComponents();
        
        // Load image using absolute path
        String imagePath = "C:/Users/ACER/Documents/NetBeansProjects/Telephone/src/images/welcome.JPG";
        try {
            backgroundImage = ImageIO.read(new File(imagePath));
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, 
                "Could not load image from:\n" + imagePath,
                "Image Error", 
                JOptionPane.ERROR_MESSAGE);
        }
        setupUI();
    }
    
    private void setupUI() {
        // Create background panel
        JPanel backgroundPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                if (backgroundImage != null) {
                    g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
                } else {
                    g.setColor(Color.LIGHT_GRAY);
                    g.fillRect(0, 0, getWidth(), getHeight());
                }
            }
        };
        
        // Make existing content transparent
        JPanel contentPane = (JPanel) getContentPane();
        contentPane.setOpaque(false);
        
        // Add components to background panel
        backgroundPanel.setLayout(new BorderLayout());
        backgroundPanel.add(contentPane, BorderLayout.CENTER);
        
        // Set the background panel as content pane
        setContentPane(backgroundPanel);
        
        // Window settings
        setTitle("Welcome to Upadhayay Telephone Service");
        setSize(800, 600);
        setLocationRelativeTo(null);
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jMenu2 = new javax.swing.JMenu();
        jMenu3 = new javax.swing.JMenu();

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setBackground(new java.awt.Color(204, 255, 255));
        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Welcome to Upadhayay Telephone Service");

        jLabel2.setBackground(new java.awt.Color(204, 204, 204));
        jLabel2.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel2.setText("Choose Type of Call");

        jButton1.setBackground(new java.awt.Color(0, 0, 0));
        jButton1.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jButton1.setForeground(new java.awt.Color(255, 255, 255));
        jButton1.setText("Lost Call");
        jButton1.setBorder(null);
        jButton1.setFocusable(false);
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setBackground(new java.awt.Color(0, 0, 0));
        jButton2.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jButton2.setForeground(new java.awt.Color(255, 255, 255));
        jButton2.setText("Delay Call");
        jButton2.setBorder(null);
        jButton2.setFocusable(false);
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jMenu1.setText("About Us");
        jMenu1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jMenu1MouseClicked(evt);
            }
        });
        jMenuBar1.add(jMenu1);

        jMenu2.setText("Help");
        jMenu2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jMenu2MouseClicked(evt);
            }
        });
        jMenuBar1.add(jMenu2);

        jMenu3.setText("Contact Us");
        jMenu3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jMenu3MouseClicked(evt);
            }
        });
        jMenuBar1.add(jMenu3);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 175, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(26, 26, 26)
                        .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 26, Short.MAX_VALUE)
                        .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(51, 51, 51)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(51, 51, 51)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 129, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton1)
                    .addComponent(jLabel2)
                    .addComponent(jButton2))
                .addGap(47, 47, 47))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        new LostCallSystem().setVisible(true);
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        new DelayCallSystem().setVisible(true);
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jMenu1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenu1MouseClicked
        String aboutMessage =
        "<html><div style='text-align: center;'>" +
        "<h2>Upadhayay Telephone Service</h2>" +
        "<p><b>Version:</b> 1.0.0</p>" +
        "<p><b>Developed by:</b> [Sushil Upadhayay]</p>" +
        "<p><b>Owner:</b> [Upadhayay Groups of Industries]</p>" +
        "<p><b>© 2023</b> All Rights Reserved</p>" +
        "</div></html>";

        // Show the dialog with an icon
        JOptionPane.showMessageDialog(
            this,                       // Parent component (the main window)
            aboutMessage,               // Formatted message
            "About Us",                 // Dialog title
            JOptionPane.INFORMATION_MESSAGE); // Message type
    }//GEN-LAST:event_jMenu1MouseClicked

    private void jMenu2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenu2MouseClicked
        String helpMessage =
        "<html><div style='text-align: left; width: 300px;'>" +
        "<h2 style='color: #0066cc;'>Lost Call System Help</h2>" +
        "<p><b>1. Starting the Simulation:</b><br>" +
        "Run <b>any Call System either LostCallSystem or DelayCallSystem </b> to begin call processing.</p>" +
        "<p><b>2. Stopping the Simulation:</b><br>" +
        "Click <b>Cross X at top</b> to end the simulation.</p>" +
        "<p><b>3. Understanding Tables:</b><br>" +
        "- <b>Next Call:</b> Shows upcoming calls<br>" +
        "- <b>Active Calls:</b> Displays ongoing calls<br>" +
        "- <b>Lines:</b> Shows telephone line status</p>" +
        "<p><b>4. Troubleshooting:</b><br>" +
        "If the system freezes, restart the application.</p>" +
        "<hr>" +
        "<p style='text-align: center;'><i>For further assistance, contact support@delaycalltelephone.com</i></p>" +
        "</div></html>";

        // Show help dialog with question icon
        JOptionPane.showMessageDialog(
            this,
            helpMessage,
            "Help Guide",
            JOptionPane.QUESTION_MESSAGE
        );
    }//GEN-LAST:event_jMenu2MouseClicked

    private void jMenu3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenu3MouseClicked
        // TODO add your handling code here:
        // contact us
        // Create a visually appealing contact message
        String contactMessage =
        "<html><div style='width: 350px; text-align: center;'>" +
        "<h2 style='color: #2E86C1;'>Contact Our Team</h2>" +
        "<p style='font-size: 14px;'><b>Upadhayay Telephone Service</b></p>" +
        "<hr style='border-top: 1px solid #D5D8DC;'>" +
        "<p><b>📞 Support Hotline:</b><br>1660 01 2356</p>" +
        "<p><b>✉ Email:</b><br>support@delaycalltelephone.com or support@lostcalltelephone.com</p>" +
        "<p><b>🏢 Address:</b><br>Kathmandu, ABC<br>Nepal</p>" +
        "<hr style='border-top: 1px solid #D5D8DC;'>" +
        "<p style='color: #5D6D7E; font-size: 12px;'>" +
        "Available Monday-Friday, 9AM-5PM PST</p>" +
        "</div></html>";
        JOptionPane.showMessageDialog(
            this,
            contactMessage,
            "Contact Us",
            JOptionPane.PLAIN_MESSAGE);
    }//GEN-LAST:event_jMenu3MouseClicked

    public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Welcome.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Welcome.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Welcome.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Welcome.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Welcome().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenu jMenu3;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JPanel jPanel1;
    // End of variables declaration//GEN-END:variables
}
